﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using PrjUpassBLL.Authentication;
using System.IO;
using PrjUpassDAL.Authentication;

namespace PrjUpassPl
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            hdnWebUrl.Value = string.Format("http{0}://{1}:{2}{3}",
                                 (Request.IsSecureConnection) ? "s" : "",
                                  Request.Url.Host,
                                  Request.Url.Port,
                                  Page.ResolveUrl("~/RandStrGenerator.asmx/GenerateRandStr")
                                );

            Cls_Business_Auth objAuth = new Cls_Business_Auth();
            String broadcastmesg = objAuth.getbroadcastmesg();
            lblbroadcast.InnerText = broadcastmesg.Trim();
            lblmsg.Text = "";
        }

        /*
        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            Hashtable credentials = new Hashtable();
            credentials["username"] = txtUsername.Text;
            credentials["password"] = txtPassword.Text;
            Cls_Business_Auth objAuth = new Cls_Business_Auth();
            Hashtable authResponse = objAuth.GetAuthResponse(credentials);
            if (authResponse["ex_ocuured"] == null)
            {
                int responseFlag = Convert.ToInt32(authResponse["response_code"]);
                string responseMsg = authResponse["response_msg"].ToString();
                if (responseFlag == 9999)
                {
                    Session["user_id"] = authResponse["user_id"];
                    Session["username"] = txtUsername.Text;
                    Session["operator_id"] = authResponse["operator_id"];
                    Session["category"] = authResponse["user_operator_category"];
                    Session["name"] = authResponse["user_name"];
                    Session["last_login"] = authResponse["last_login"];
                    lblLoginResult.Text = "User login successful";
                    Response.Redirect("~/Dashboard.aspx");
                }
                else
                {
                    lblLoginResult.Text = responseMsg;
                }
            }
            else {
                Response.Redirect("~/ErrorPage.aspx");
            }
        }
         */

        protected void ibtLogIn_Click(object sender, ImageClickEventArgs e)
        {
            Cls_Data_Auth auth = new Cls_Data_Auth();
            string Ip = auth.GetIPAddress(HttpContext.Current.Request);
            Hashtable credentials = new Hashtable();
            credentials["username"] = txtUsername.Text;
            credentials["password"] = txtPassword.Text;
            credentials["IP"] = Ip;

            Cls_Business_Auth objAuth = new Cls_Business_Auth();
            Hashtable authResponse = objAuth.GetAuthResponse(credentials);
            if (authResponse["ex_ocuured"] == null)
            {
                int responseFlag = Convert.ToInt32(authResponse["response_code"]);
                string responseMsg = authResponse["response_msg"].ToString();
                if (responseFlag == 9999)
                {
                    Session["user_id"] = authResponse["user_id"];
                    Session["user_brmpoid"] = authResponse["user_brmpoid"];
                    Session["username"] = txtUsername.Text;
                    Session["operator_id"] = authResponse["operator_id"];
                    Session["category"] = authResponse["user_operator_category"];
                    Session["name"] = authResponse["user_name"];
                    Session["last_login"] = authResponse["last_login"];
                    Session["login_flag"] = authResponse["login_flag"];
                    lblLoginResult.Text = "User login successful";
                    if (authResponse["user_operator_category"].ToString() == "3")
                    {
                        //if Logged in user is LCO
                        Response.Redirect("~/Reports/rptLCOAllDetails.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/Transaction/Home.aspx");
                    }

                }
                else
                {
                    txtUsername.Text = "";
                    txtPassword.Text = "";
                    txtUsername.Focus();
                    string script = "<script language=\"javascript\" type=\"text/javascript\">alert('" + responseMsg + "');</script>";
                    Response.Write(script);
                }
            }
            else
            {
                Response.Redirect("~/ErrorPage.aspx");
            }
        }

        public void msgbox(string message, Control ctrl)
        {
            string msg = "<script type=\"text/javascript\">alert(\"" + message + "\");</script>";
            Page.ClientScript.RegisterStartupScript(this.GetType(), "msg", msg);
            ctrl.Focus();
        }

        protected void btnreset_Click(object sender, EventArgs e)
        {
            btnreset.Enabled = false;
            if (txtname.Text.Trim() == "")
            {
                msgbox("Please Enter UserName", txtname);
                return;
            }
            Cls_Data_Auth auth = new Cls_Data_Auth();
            string Ip = auth.GetIPAddress(HttpContext.Current.Request);

            Hashtable ht = new Hashtable();
            ht.Add("UserName", txtname.Text.Trim());
            ht.Add("IP", Ip);
            Cls_Bussiness_forgotpass objbuss = new Cls_Bussiness_forgotpass();
            string response = objbuss.ForgotDetails(ht);
            if (response == "ex_occured")
            {
                Response.Redirect("~/ErrorPage.aspx");
                return;
            }
            lblmsg.Visible = true;
            // lblmsg.Text = response;
            Session["txt"] = response;
            lblmsg.Text = Session["txt"].ToString();
            btnreset.Enabled = true;
            // txtname.Text = "";
            ModalPopupExtender1.Show();
        }

        protected void lnkforgot_Click1(object sender, EventArgs e)
        {
            lblmsg.Text = "";
            txtname.Text = "";
            ModalPopupExtender1.Show();
        }
    }
}